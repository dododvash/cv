#include <cvidef.h>
extern DLLIMPORT int PrintLen;
extern void DllPrint(int k);
