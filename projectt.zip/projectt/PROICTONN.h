/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  PANEL                            1
#define  PANEL_QUITBUTTON                 2       /* control type: command, callback function: QuitCallback */
#define  PANEL_PLAY                       3       /* control type: command, callback function: PLAY */
#define  PANEL_FINAL                      4       /* control type: command, callback function: FINAL */
#define  PANEL_player3                    5       /* control type: picture, callback function: (none) */
#define  PANEL_winplayer1                 6       /* control type: numeric, callback function: (none) */
#define  PANEL_player2                    7       /* control type: picture, callback function: (none) */
#define  PANEL_player1                    8       /* control type: picture, callback function: (none) */
#define  PANEL_winplayer2                 9       /* control type: numeric, callback function: (none) */
#define  PANEL_winplayer3                 10      /* control type: numeric, callback function: (none) */
#define  PANEL_winer                      11      /* control type: command, callback function: winer */
#define  PANEL_totalgame                  12      /* control type: numeric, callback function: (none) */

#define  PANEL2                           2
#define  PANEL2_TAB                       2       /* control type: tab, callback function: (none) */

     /* tab page panel controls */
#define  player11_mean1                   2       /* control type: numeric, callback function: (none) */
#define  player11_stddev1                 3       /* control type: numeric, callback function: (none) */
#define  player11_winingplayer1           4       /* control type: graph, callback function: (none) */

     /* tab page panel controls */
#define  player22_mean2                   2       /* control type: numeric, callback function: (none) */
#define  player22_stddev2                 3       /* control type: numeric, callback function: (none) */
#define  player22_winingplayer2           4       /* control type: graph, callback function: (none) */

     /* tab page panel controls */
#define  player33_mean3                   2       /* control type: numeric, callback function: (none) */
#define  player33_srddev3                 3       /* control type: numeric, callback function: (none) */
#define  player33_winingplayer3           4       /* control type: graph, callback function: (none) */


     /* Control Arrays: */

          /* (no control arrays in the resource file) */


     /* Menu Bars, Menus, and Menu Items: */

#define  MENUBAR                          1
#define  MENUBAR_graph                    2       /* callback function: graph */


     /* Callback Prototypes: */

int  CVICALLBACK FINAL(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
void CVICALLBACK graph(int menubar, int menuItem, void *callbackData, int panel);
int  CVICALLBACK PLAY(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK QuitCallback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK winer(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif
