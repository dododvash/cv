#include <ansi_c.h>
DLLEXPORT int  PrintLen = 10;
void DllPrint(int k)
{
				   if(k==1)
				   {
						printf("the winer is player 1\n");
				   }
				   if(k==2)
				   {   
			 	printf("the winer is player 2\n");
				   }
				   if(k==3)
				   {
		 	printf("the winer is player 3\n");
				   }
	
}
