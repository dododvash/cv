#include <analysis.h>
#include "toolbox.h"
#include <ansi_c.h>
#include <cvirte.h>		
#include <userint.h>
#include "PROICTONN.h"
#include "po.h"

static int panelHandle;
	static double count1=0,count2=0,count3=0,ii,iii,iiii,j1=1,j2,j3,b2[1000],b3[1000],p1,p2,p3,b1[1000],count5=0;
	static int o1,o2,o3,o4,o5,o6,o7,o8,o9,o10,o11,o12,o13,o14,o16,o17,o18,o19,o20,o21,o22,o23,o24,o25,o26,o27,o28,o29,o30,a[53],z1=0,ph2;
	static int o31,o32,o33,o34,o35,o36,o37,o38,o39,o40,o41,o42,o43,o44,o45,o46,o47,o48,o49,o50,o51,o52,o15,z2=0,z3=0,tab0,tab1,tab2;
	static int i,i2,i1,k,flag=0,f2;

int main (int argc, char *argv[])
{
	if (InitCVIRTE (0, argv, 0) == 0)
		return -1;	/* out of memory */
	if ((panelHandle = LoadPanel (0, "PROICTONN.uir", PANEL)) < 0)
		return -1;
ph2 = LoadPanel (0, "c:\\projectt\\PROICTONN.uir", PANEL2);

	DisplayPanel (panelHandle);
	RunUserInterface ();
	DiscardPanel (panelHandle);
	return 0;
}

int CVICALLBACK QuitCallback (int panel, int control, int event,
							  void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			QuitUserInterface (0);
			break;
	}
	return 0;
}

	int CVICALLBACK Function2 (void *functionData)
{
	double k,i=3;
	
	while(1)
	{
		count5++;
		SetCtrlVal (panelHandle, PANEL_totalgame, count5);
	 	 if(flag==1)
		 {
		Delay (0.3);
			 break; 
		 }
	}
	flag=1;


	return 0;
	
}


int CVICALLBACK PLAY (int panel, int control, int event,
					  void *callbackData, int eventData1, int eventData2)
{ 

	switch (event)
	{
		case EVENT_COMMIT:
	  GetBitmapFromFile ("c:\\projectt\\1.jpg", &o1);
	  a[1] =o1; 
	   GetBitmapFromFile ("c:\\projectt\\1A.jpg", &o2);
	  a[2] =o2; 
	GetBitmapFromFile ("c:\\projectt\\1B.jpg", &o3);
	  a[3] =o3; 	
	   GetBitmapFromFile ("c:\\projectt\\1C.jpg", &o4);
	  a[4] =o4; 
	   GetBitmapFromFile ("c:\\projectt\\2.jpg", &o5);
	  a[5] =o5; 
	   GetBitmapFromFile ("c:\\projectt\\2A.jpg", &o6);
	  a[6] =o6; 
	GetBitmapFromFile ("c:\\projectt\\2B.jpg", &o7);
	  a[7] =o7; 
	  GetBitmapFromFile ("c:\\projectt\\2C.jpg", &o8);
	  a[8] =o8; 
	  GetBitmapFromFile ("c:\\projectt\\3.jpg", &o9);
	  a[9] =o9; 
	  GetBitmapFromFile ("c:\\projectt\\3A.jpg", &o10);
	  a[10] =o10; 
	  GetBitmapFromFile ("c:\\projectt\\3B.jpg", &o11);
	  a[11] =o11; 
	  GetBitmapFromFile ("c:\\projectt\\3C.jpg", &o12);
	  a[12] =o12; 
	  GetBitmapFromFile ("c:\\projectt\\4.jpg", &o13);
	  a[13] =o13; 
	  GetBitmapFromFile ("c:\\projectt\\4A.jpg", &o14);
	  a[14] =o14; 
	  GetBitmapFromFile ("c:\\projectt\\4B.jpg", &o15);
	  a[15] =o15; 
	  GetBitmapFromFile ("c:\\projectt\\4C.jpg", &o16);
	  a[16] =o16; 
	  GetBitmapFromFile ("c:\\projectt\\5.jpg", &o17);
	  a[17] =o17; 
	  GetBitmapFromFile ("c:\\projectt\\5A.jpg", &o18);
	  a[18] =o18; 
	  GetBitmapFromFile ("c:\\projectt\\5B.jpg", &o19);
	  a[19] =o19; 
	  GetBitmapFromFile ("c:\\projectt\\5C.jpg", &o20);
	  a[20] =o20; 
	  GetBitmapFromFile ("c:\\projectt\\6.jpg", &o21);
	  a[21] =o21; 
	  GetBitmapFromFile ("c:\\projectt\\6A.jpg", &o22);
	  a[22] =o22; 
	  GetBitmapFromFile ("c:\\projectt\\6B.jpg", &o23);
	  a[23] =o23; 
	  GetBitmapFromFile ("c:\\projectt\\6C.jpg", &o24);
	  a[24] =o24; 
	  GetBitmapFromFile ("c:\\projectt\\7.jpg", &o25);
	  a[25] =o25; 
	  GetBitmapFromFile ("c:\\projectt\\7A.jpg", &o26);
	  a[26] =o26; 
	  GetBitmapFromFile ("c:\\projectt\\7B.jpg", &o27);
	  a[27] =o27; 
	  GetBitmapFromFile ("c:\\projectt\\7C.jpg", &o28);
	  a[28] =o28; 
	  GetBitmapFromFile ("c:\\projectt\\8.jpg", &o29);
	  a[29] =o29; 
	  GetBitmapFromFile ("c:\\projectt\\8A.jpg", &o30);
	  a[30] =o30; 
	  GetBitmapFromFile ("c:\\projectt\\8B.jpg", &o31);
	  a[31] =o31; 
	  GetBitmapFromFile ("c:\\projectt\\8C.jpg", &o32);
	  a[32] =o32; 
	  GetBitmapFromFile ("c:\\projectt\\9.jpg", &o33);
	  a[33] =o33; 
	  GetBitmapFromFile ("c:\\projectt\\9A.jpg", &o34);
	  a[34] =o34; 
	  GetBitmapFromFile ("c:\\projectt\\9B.jpg", &o35);
	  a[35] =o35; 
	  GetBitmapFromFile ("c:\\projectt\\9C.jpg", &o36);
	  a[36] =o36; 
	  GetBitmapFromFile ("c:\\projectt\\10.jpg", &o37);
	  a[37] =o37; 
	  GetBitmapFromFile ("c:\\projectt\\10A.jpg", &o38);
	  a[38] =o38; 
	  GetBitmapFromFile ("c:\\projectt\\10B.jpg", &o39);
	  a[39] =o39; 
	  GetBitmapFromFile ("c:\\projectt\\10C.jpg", &o40);
	  a[40] =o40; 
	  GetBitmapFromFile ("c:\\projectt\\11.jpg", &o41);
	  a[41] =o41; 
	  GetBitmapFromFile ("c:\\projectt\\11A.jpg", &o42);
	  a[42] =o42; 
	  GetBitmapFromFile ("c:\\projectt\\11B.jpg", &o43);
	  a[43] =o43; 
	  GetBitmapFromFile ("c:\\projectt\\11C.jpg", &o44);
	  a[44] =o44; 
	  GetBitmapFromFile ("c:\\projectt\\12.jpg", &o45);
	  a[45] =o45; 
	  GetBitmapFromFile ("c:\\projectt\\12A.jpg", &o46);
	  a[46] =o46; 
	  GetBitmapFromFile ("c:\\projectt\\12B.jpg", &o47);
	  a[47] =o47; 
	  GetBitmapFromFile ("c:\\projectt\\12C.jpg", &o48);
	  a[48] =o48; 
	  GetBitmapFromFile ("c:\\projectt\\13.jpg", &o49);
	  a[49] =o49; 
	  GetBitmapFromFile ("c:\\projectt\\13A.jpg", &o50);
	  a[50] =o50; 
	    GetBitmapFromFile ("c:\\projectt\\13B.jpg", &o51);
	  a[51] =o51; 
	   GetBitmapFromFile ("c:\\projectt\\13C.jpg", &o52);
	  a[52] =o52; 

	 i = Random (1, 52);
	 i1=Random (1, 52);
	 i2=Random (1, 52);
	SetCtrlBitmap (panelHandle, PANEL_player1, 0, a[i]);
	SetCtrlBitmap (panelHandle, PANEL_player2, 0, a[i1]);
	SetCtrlBitmap (panelHandle, PANEL_player3, 0, a[i2]);
	if(i>=1&&i<=4)
	{
		i=i+60;
	}
	if(i1>=1&&i1<=4)
	{
		i1=i1+60;
	}
	if(i2>=1&&i2<=4)
	{
		i2=i2+60;
	}

	if(i>i2&&i>i1) 
	{
		 if(1<=abs(i-i1)&&abs(i-i1)<=3)
			 {
				 count2=count2+1;
				 b2[z2]=count2;
					z2++;
				 
			 }
			  if(1<=abs(i-i2)&&abs(i-i2)<=3)
			 {
				 count3=count3+1;
				 b3[z3]=count3;
					z3++;
				  
			 }
			 else
		
	count1=count1+1;
	 b1[z1]=count1;
	z1++;
	}
	if(i1>i2&&i1>i)
	{
		  if(1<=abs(i1-i)&&abs(i1-i)<=3)
			 {
				
				 	count1=count1+1;
					b1[z1]=count1;
					z1++;
			 }
			  if(1<=abs(i1-i2)&&abs(i1-i2)<=3)
			  	  
			 {
				 	count3=count3+1; 
					b3[z3] =count3;
					z3++;
			 }
			
	count2=count2+1;
	b2[z2] =count2;
	z2++;
	
	}
	 	if(i2>i&&i2>i1)
	{
		 if(1<=abs(i2-i1)&&abs(i2-i1)<=3)
			 {
				 count2=count2+1;
				 	b2[z2] =count2;
                  	z2++;
				  
			 }
			  if(1<=abs(i2-i)&&abs(i2-i)<=3)
			 {
				 count1=count1+1;
				 	b1[z1] =count1;
                	z1++;
				  
			 }
	
			 
	count3=count3+1;
	b3[z3] =count3;
   	z3++;
	}
	
			
			 
		SetCtrlVal (panelHandle, PANEL_winplayer1, count1);
		SetCtrlVal (panelHandle, PANEL_winplayer2, count2);
		SetCtrlVal (panelHandle, PANEL_winplayer3, count3);
		flag=1;
		CmtScheduleThreadPoolFunction (DEFAULT_THREAD_POOL_HANDLE, Function2, NULL, &f2);
			  
	
		 
			
			 
			

			break;
	}
	return 0;
}

int CVICALLBACK FINAL (int panel, int control, int event,
					   void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			                                     	 GetPanelHandleFromTabPage (ph2, PANEL2_TAB, 0, &tab0); 
				
													 GetPanelHandleFromTabPage (ph2, PANEL2_TAB, 1, &tab1);
												
													 GetPanelHandleFromTabPage (ph2, PANEL2_TAB, 2, &tab2);
						StdDev (b1, z1, &j1, &p1);
						StdDev (b2, z2, &j2, &p2);
						StdDev (b3, z3, &j3, &p3);
			SetCtrlVal (tab0, player11_mean1, j1);
			 SetCtrlVal (tab0, player11_stddev1, p1);
			 SetCtrlVal (tab1, player22_mean2, j2);
			 SetCtrlVal (tab1, player22_stddev2, p2);
			 SetCtrlVal (tab2, player33_mean3, j3);
			 SetCtrlVal (tab2, player33_srddev3, p3);
		
			  PlotY (tab0, player11_winingplayer1, b1, z1, VAL_DOUBLE, VAL_SCATTER, VAL_SOLID_SQUARE, VAL_SOLID, 1, VAL_RED);
			 PlotY (tab1, player11_winingplayer1, b2, z2, VAL_DOUBLE, VAL_SCATTER, VAL_SOLID_SQUARE, VAL_SOLID, 1, VAL_RED);
			PlotY (tab2, player11_winingplayer1, b3, z3, VAL_DOUBLE, VAL_SCATTER, VAL_SOLID_SQUARE, VAL_SOLID, 1, VAL_RED);
		   
			
	
		
				  
			 
			

			break;
	}
	return 0;
}
							

void CVICALLBACK graph (int menuBar, int menuItem, void *callbackData,
						int panel)
{
	DisplayPanel (ph2);
	
			 

	   






	
}

int CVICALLBACK winer (int panel, int control, int event,
					   void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			if(count1>count2&&count1>count3)
				k=1;
				if(count2>count1&&count2>count3)
				k=2;
					if(count3>count2&&count3>count1)
				k=3;
			  DllPrint(k) ; 

			break;
	}
	return 0;
}
